from flask import Flask, render_template, request, session, redirect, url_for

app = Flask(__name__)
app.secret_key = "secret_key_for_session"

@app.route("/", methods=["GET", "POST"])
def game():
    if "low" not in session:
        session["low"] = 1
        session["high"] = 100
        session["guess"] = (session["low"] + session["high"]) // 2
        session["tries"] = 1
        session["message"] = ""

    if request.method == "POST":
        action = request.form["action"]
        low, high = session["low"], session["high"]
        guess = session["guess"]
        tries = session["tries"]

        if action == "higher":
            low = guess + 1
            tries += 1
        elif action == "lower":
            high = guess - 1
            tries += 1
        elif action == "correct":
            session["message"] = f"🎉 آفرین! عدد شما ({guess}) در {tries} حدس پیدا شد."
            return render_template("game.html", guess=guess, message=session["message"])

        if low > high:
            session["message"] = "😅 به نظر پاسخ‌ها ناسازگار هستند!"
            return render_template("game.html", guess=guess, message=session["message"])

        session["low"], session["high"], session["guess"], session["tries"] = low, high, (low + high)//2, tries

    return render_template("game.html", guess=session["guess"], message=session.get("message",""))

if __name__ == "__main__":
    app.run(debug=True)
